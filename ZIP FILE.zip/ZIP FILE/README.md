# CodeAlpha Internship Tasks (C Programming)

## 👩‍💻 Author:MANSI SUBHASH PATIL

Mansi Patil

---

## 📌 Task 1: Simple Calculator

### Description:

This program performs basic arithmetic operations like addition, subtraction, multiplication, and division using a menu-driven approach.

### Features:

* Addition
* Subtraction
* Multiplication
* Division
* Error handling for division by zero

---

## 📌 Task 2: Matrix Operations

### Description:

This program performs various matrix operations such as addition, multiplication, and transpose using functions.

### Features:

* Matrix Addition
* Matrix Multiplication
* Transpose of Matrix
* Display Matrices

---

## 📌 Task 3: Student Management System

### Description:

This project manages student records using file handling in C.

### Features:

* Add Student
* Display Students
* Search Student
* Update Student
* Delete Student

---

## 📌 Task 4: Banking System

### Description:

This project simulates a simple banking system using file handling. It allows users to manage bank accounts efficiently.

### Features:

* Create Account
* Deposit Money
* Withdraw Money
* Balance Enquiry
* Display All Accounts

---

## ⚙️ Technologies Used:

* C Programming
* File Handling

---

## ▶️ How to Run:

1. Open terminal / command prompt

2. Compile the program:
   gcc filename.c

3. Run the program:
   ./a.out

---

## 📂 Files Included:

* Task1_Calculator.c
* Task2_Matrix.c
* Task3_StudentManagement.c
* Task4_BankingSystem.c
* README.txt

---
📸 Output:

Output screenshots are included in the ZIP file.

 ✅ Conclusion:

These tasks demonstrate basic to intermediate C programming concepts including conditional statements, loops, functions, arrays, and file handling.
